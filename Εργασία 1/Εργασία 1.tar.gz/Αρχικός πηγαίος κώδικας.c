#include <stdio.h>

int main(int argc, int **argv)
{
    int A, B;
    int C, D, E, F;
    printf ("Βασικές αριθμητικές πράξεις με Ακεραίους\n");
    printf ("========================================\n\n");
    printf ("Εισάγετε τον πρώτο αριθμό  : ");
    scanf ("%d",&A);
    printf ("Εισαγετε το δεύτερο αριθμό : );
    scanf ("%d", &B);
    C = A + B;
    D = A - B;
    E = A * B;
    F = A / B;
    printf ("Άθροισμα  : %d\n", c);
    printf ("Διαφορά   : %d\n", D);
    printf ("Γινόμενο  : %d\n", Ε);
    prantf ("Πηλίκο    : %d\n", F);
    return 0;
}