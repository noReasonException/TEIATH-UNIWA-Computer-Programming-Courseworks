#include <iostream>
#include <stdio.h>

int main() {
    printf("Short Int -> %d\n",sizeof(short int));
    printf("Unsigned Short Int-> %d\n",sizeof(unsigned short int));
    printf("Unsigned Int->%d\n",sizeof(unsigned int));
    printf("Int ->%d\n",sizeof(int));
    printf("Long Int->%d\n",sizeof(long int));
    printf("Unsigned Long Int->%d\n",sizeof(unsigned long int));
    printf("Unsigned Char-> %d\n",sizeof(unsigned char));
    printf("Float-> %d\n",sizeof(float));
    printf("Double-> %d\n",sizeof(double));
    printf("Long Double->%d\n",sizeof(long double));
}